#include <stdio.h>
#include <stdlib.h>
#define len sizeof(struct worker)
struct worker
{
	int id;
 	char name[10];
	float salary;
}temp;
void fun(struct worker *p,int x)
{
	int i,j;
	for(i=0;i<x-1;i++)
	{
		for(j=i+1;j<x;j++)
		{
			if(p[i].salary>p[j].salary)
			{
				temp=p[i];
				p[i]=p[j];
				p[j]=temp;
			}			
		}
	}
}
int main()
{
	FILE *fp;
	struct worker a[100];
	struct worker worker[100];
	int i=0,j=0,cnt=0;
	if((fp=fopen("workerline.dat","rb"))==NULL) 
	{
		printf("cannot open file!\n");
		exit(0);
	}
	for(i=0;(!feof(fp));i++)
	{
		fread(&worker[i],len,1,fp);
			if(worker[i].salary<=5000)
			{
				a[j]=worker[i];
				j++;
			}								
	}
	cnt=j;
	fun(a,cnt);
	for(i=0;i<cnt;i++)
		printf("worker:  id:%d  name:%s  salary:%f",a[i].id,a[i].name,a[i].salary);
	fclose(fp);
	system("pause"); 
	return 0;
}

