#include<stdio.h>
void fun(char *s);
int main()
{
	char str[80];
	gets(str);
	fun(str);
	return 0;
}

void fun(char *s)
{
	char t[80];
	int i=0,j=0;
	while(s[i]!='\0')
	{
		if(i%2!=0&&s[i]%2==0)
		{
			t[j]=s[i];
			j++;
		}
		i++;
	}
	t[i]='\0';
	puts(t);
}
