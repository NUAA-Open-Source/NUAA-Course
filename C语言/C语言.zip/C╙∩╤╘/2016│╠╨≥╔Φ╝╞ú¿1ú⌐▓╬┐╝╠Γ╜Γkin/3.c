#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct student
{	
	char num[11];	//ѧ��	
	char name[10];	 // ����
	int  age;		// ����
	char gender;	 // �Ա�����M��ʾ������F��ʾŮ��
} STU;

STU list[30], temp;

void SortByAge(int n)
{
	int i, j;
	
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n - i - 1; j++)
		{
			if (list[j].age < list[j + 1].age)
			{
				//ʹ���ڴ�ֱ�Ӹ��ƣ��ȼ�����Ӧ��ֵ(int, char��'=', �ַ�������strcpy)
				memcpy((void *)&temp, (void *)&list[j], sizeof(STU));
				memcpy((void *)&list[j], (void *)&list[j + 1], sizeof(STU));
				memcpy((void *)&list[j + 1], (void *)&temp, sizeof(STU));
			}
		}
	}
}

int main()
{
	int n = 0, i;
	FILE *fp;
	
	fp = fopen("student.dat", "rb");
	if (!fp)
	{
		printf("ERROR");
		exit(1);
	}
	printf("Size of each student: %d bytes\n", sizeof(STU));
	printf("Data in 'student.dat':\n");
	while (1)
	{
		fread((void *)&list[n], sizeof(STU), 1, fp);
		if (feof(fp))
		{
			fclose(fp);
			break;
		}
		printf("%12s%11s%3d%2c\n", list[n].num, list[n].name, list[n].age, list[n].gender);
		n++;
	}
	printf("Count of students: %d\n", n);
	
	SortByAge(n);
	printf("Data sorted:\n");
	for (i = 0; i < n; i++)
	{
		printf("%12s%11s%3d%2c\n", list[i].num, list[i].name, list[i].age, list[i].gender);
	}
	
	fp = fopen("newstu.dat", "wb");
	printf("Now write data into 'newstu.dat'...\n");
	for (i = 0; i < n; i++)
	{
		if (i == 4)
		{
			continue;
		}
		fwrite((void *)&list[i], sizeof(STU), 1, fp);
	}
	fclose(fp);
	
	fp = fopen("newstu.dat", "rb");
	i = 0;
	printf("Data in newstu.dat:\n");
	while (1)
	{
		fread((void *)&list[i], sizeof(STU), 1, fp);
		if (feof(fp))
		{
			fclose(fp);
			break;
		}
		printf("%12s%11s%3d%2c\n", list[i].num, list[i].name, list[i].age, list[i].gender);
		i++;
	}
	
	return 0;
}
