#include <stdio.h>

int fun(int *n)
{
	int len = 0, newnum = 0, oldnum = *n, tens = 1;
	int single, i;
	
	while (oldnum > 0)
	{
		single = oldnum % 10;
		if (single % 2 != 1)
		{
			newnum += single * tens;
			tens *= 10;
			len++;
		}
		oldnum /= 10;
	}
	*n = newnum;
	
	return len;
}

int test(int num)
{
	int length;
	printf("fun(%d)\n", num);
	length = fun(&num);
	printf("New number: %d Length: %d\n", num, length);
}

int main()
{
	int i;
	int arr[10] = {87698432, 123456, 654321, 145569, 112314,
					 1, 2, 77665544, 111111, 666666};
		
	printf("Just test 10 typical data:\n");
	printf("'Length == 0' means this number does not exist\n");
	for (i = 0; i < 10; i++)
	{
		printf("\nTest %d:\n", i + 1);
		test(arr[i]);
	}
	
	return 0;
}
