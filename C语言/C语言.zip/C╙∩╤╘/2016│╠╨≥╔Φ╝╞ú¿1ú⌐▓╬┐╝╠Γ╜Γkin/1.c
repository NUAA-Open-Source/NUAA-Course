#include <stdio.h>
#define BLACK 0
#define WHITE 1

int main()
{
	int a, b, c, d, e;
	
	printf("0 is for BLACK\n1 is for WHITE\n");
	for (a = 0; a < 2; a++)
	{
		for (b = 0; b < 2; b++)
		{
			for (c = 0; c < 2; c++)
			{
				for (d = 0; d < 2; d++)
				{
					for (e = 0; e < 2; e++)
					{
						if (   (a == WHITE && b + c + d + e == 3 || a == BLACK && b + c + d + e != 3)
							&& (b == WHITE && a + c + d + e == 0 || b == BLACK && a + c + d + e != 0)
							&& (c == WHITE && a + b + d + e == 1 || c == BLACK && a + b + d + e != 1)
							&& (d == WHITE && a + b + c + e == 4 || d == BLACK && a + b + c + e != 4))
						{
							printf("A: %d B: %d C: %d D: %d E: %d\n", a, b, c, d, e);
						}
					}
				}
			}
		}
	}
	
	return 0;
}
